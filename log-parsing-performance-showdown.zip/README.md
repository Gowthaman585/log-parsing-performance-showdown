Log parsing performance showdown
